/*Hlavičkový soubor pro testovací funkce*/

/*Jaroslav Zikmund leden 2026*/


/*
*podmíněný překladový příkaz proti vícenásobnému zahrnutí
*/
#ifndef TEST_H
#define TEST_H  

/*=============== Testovací fce =================*/

void run_tests();

#endif // TEST_H